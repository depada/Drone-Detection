import React from "react";

const Output = () => {
  return <div>Output</div>;
};

export default Output;
