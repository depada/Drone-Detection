import React from "react";
import "./App.css";
import Input from "./Components/Input";
import Header from "./Components/Header";
import Output from "./Components/Output";

const App = () => {
  return (
    <div>
      <Header />
      <Input />
      {/* <Output /> */}
    </div>
  );
};

export default App;
